export declare function setSharedScope(scope: any): void;
export declare function getSharedModule<T = any>(moduleName: string): T;
