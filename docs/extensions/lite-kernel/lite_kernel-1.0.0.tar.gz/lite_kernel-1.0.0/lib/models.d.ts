export declare const WEBLLM_MODELS: string[];
export declare const DEFAULT_WEBLLM_MODEL: string;
export declare function isValidWebLLMModel(id: string): boolean;
